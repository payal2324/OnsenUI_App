### 5.0.1 (Dec 27, 2017)
* [CB-13709](https://issues.apache.org/jira/browse/CB-13709) Fix to allow 5.0.0 version install (#144)

