### 2.0.1 (Dec 27, 2017)
* [CB-13700](https://issues.apache.org/jira/browse/CB-13700) Fix to allow 2.0.0 version install (#62)

